package com.mycompany.myapp.dto;

public class PasswdChange {
	private String mid;
	private String plink;
	
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getPlink() {
		return plink;
	}
	public void setPlink(String plink) {
		this.plink = plink;
	}

}
